package com.mycompany.calcengine.exceptiontypes;

public enum MathOperation {
    ADD,
    SUBTRACT,
    MULTIPLY,
    DIVIDE
}
